$(".button").click(function(){
    $(this).addClass("active").siblings().removeClass("active");
    const filter = $(this).attr("data-filter");
    if(filter == 'all'){
        $('.project').show(400);
    }else{
        $('.project').not('.'+filter).hide(200);
        $('.project').filter('.'+filter).show(400);
    }
});
$('.project-info').magnificPopup({
    delegate:'a',
    type:'image',
    gallery:{
        enabled:true 
    },
    mainClass: 'mfp-fade'

});
$('.owl-carousel').owlCarousel({
    loop:true,
    autoplay:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        }
    }

});

$('.counter').counterUp({
    delay: 10,
    time: 1000
});

            // $(document).ready(function(){});